CREATE PROCEDURE ProgramsPro
	@ProgamName VARCHAR(50),
	@ProgContactEmail VARCHAR(50),
	@ProgContactName VARCHAR(50),
	@ProgStartDate DATE
AS
BEGIN
	INSERT INTO Programs
	(
		ProgramName,ProgContactEmail,ProgContactName,ProgStartDate
	)
	VALUES
	(
		@ProgamName,@ProgContactEmail,@ProgContactName,@ProgStartDate
	)
END