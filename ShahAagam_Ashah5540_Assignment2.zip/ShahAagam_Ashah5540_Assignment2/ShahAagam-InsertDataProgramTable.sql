--select * from Students
--select * from Programs

INSERT INTO Programs
VALUES 
	(
		'Animation','Animation@conestogac.com','Aagam','2024-01-20'
	)
INSERT INTO Programs 
VALUES 
	(
		'Bartending','Bartending@conestogac.com','Jinali','2024-02-21'
	)
INSERT INTO Programs  
VALUES 
	(
		'Bookkeeping','Bookkeeping@conestogac.com','Sanjay','2024-03-22'
	)
INSERT INTO Programs  
VALUES 
	(
		'Business','Business@conestogac.com','Rupal','2024-04-23'
	)
INSERT INTO Programs  
VALUES 
	(
		'Esthetician','Esthetician@conestogac.com','Yash','2024-05-24'
	)
INSERT INTO Programs  
VALUES 
	(
		'Journalism','Journalism@conestogac.com','Kaivan','2024-06-25'
	)
INSERT INTO Programs  
VALUES 
	(
		'Paramedic','Paramedic@conestogac.com','Nilesh','2024-07-26'
	)
INSERT INTO Programs  
VALUES 
	(
		'Finance','Finance@conestogac.com','Alpa','2024-08-27'
	)
INSERT INTO Programs  
VALUES 
	(
		'IT','IT@conestogac.com','Naman','2024-09-28'
	)
INSERT INTO Programs 
VALUES 
	(
		'Healthcare','Healthcare@conestogac.com','Manasi','2024-10-29'
	)
