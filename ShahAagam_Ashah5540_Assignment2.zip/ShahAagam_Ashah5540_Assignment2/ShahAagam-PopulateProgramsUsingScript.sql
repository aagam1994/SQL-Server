USE [ShahAagam]
GO

SELECT [ProgramCode]
      ,[ProgramName]
      ,[ProgContactEmail]
      ,[ProgContactName]
      ,[ProgStartDate]
  FROM [dbo].[Programs]

GO


