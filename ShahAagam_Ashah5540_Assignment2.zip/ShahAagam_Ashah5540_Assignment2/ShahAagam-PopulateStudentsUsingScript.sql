USE [ShahAagam]
GO

SELECT [StudentID]
      ,[SocialInsuranceNumber]
      ,[Firstname]
      ,[Lastname]
      ,[EmailAddress]
      ,[PhoneNumber]
      ,[StartDate]
  FROM [dbo].[Students]

GO