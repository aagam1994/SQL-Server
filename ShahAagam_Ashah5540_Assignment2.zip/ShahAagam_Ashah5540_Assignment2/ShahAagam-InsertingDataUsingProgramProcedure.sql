--SELECT * FROM Programs

EXEC dbo.ProgramsPro 'Arts','Arts@conestogac.com','Nihar','2024-01-17'
EXEC dbo.ProgramsPro 'Robotics','Robotics@conestogac.com','Jay','2024-01-18'
EXEC dbo.ProgramsPro 'Dental','Dental@conestogac.com','Mihir','2024-01-19'

