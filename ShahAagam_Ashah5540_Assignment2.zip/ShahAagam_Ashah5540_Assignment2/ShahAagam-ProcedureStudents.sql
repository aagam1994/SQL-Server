CREATE PROCEDURE StudentsPro
	@SocialInsuranceNumber CHAR(11),
	@FirstName VARCHAR(50),
	@LastName VARCHAR(50),
	@EmailAddrerss VARCHAR(50),
	@PhoneNumber VARCHAR(50),
	@StartDate DATE
AS
BEGIN
	INSERT INTO Students
	(
		SocialInsuranceNumber,Firstname,Lastname,EmailAddress,PhoneNumber,StartDate
	)
	VALUES
	(
		@SocialInsuranceNumber,@FirstName,@LastName,@EmailAddrerss,@PhoneNumber,@StartDate
	)
END