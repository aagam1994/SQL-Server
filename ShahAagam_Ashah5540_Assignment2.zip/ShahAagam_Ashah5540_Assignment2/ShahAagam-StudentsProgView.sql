CREATE VIEW StudentsProgView
AS
SELECT 
	Students.Firstname, Students.Lastname, Students.EmailAddress,
	Programs.ProgramName,Programs.ProgContactName, Programs.ProgContactEmail
FROM Programs
INNER JOIN Students
	ON
	(
		PROGRAMS.ProgStartDate = Students.StartDate
	)

