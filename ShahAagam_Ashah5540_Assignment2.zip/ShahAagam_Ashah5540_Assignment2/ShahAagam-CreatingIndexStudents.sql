CREATE INDEX IndexStudents
ON
	Students
	(
		Firstname,
		Lastname,
		EmailAddress
	)



	--select * from Students