CREATE INDEX IndexPrograms
ON
	Programs
	 (
		ProgramName,
		ProgContactName,
		ProgContactEmail
	 )

--select * from Programs