INSERT INTO Students
VALUES 
	(
		'981-911-140','Vaibhav','Shah','Vaibhav@gmail.com','4377662701','2024-01-20'
	)
INSERT INTO Students 
VALUES 
	(
		'981-911-141','Vyoma','Shah','Vyoma@gmail.com','4377662702','2024-02-21'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-142','Jinay','Shah','Jinay@gmail.com','4377662703','2024-03-22'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-143','Manay','Shah','Manay@gmail.com','4377662704','2024-04-23'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-144','Bhavesh','Shah','Bhavesh@gmail.com','4377662705','2024-05-24'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-145','Dhavan','Shah','Dhavan@gmail.com','4377662706','2024-06-25'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-146','Archana','Shah','Archana@gmail.com','4377662707','2024-07-26'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-147','Rishab','Shah','Rishab@gmail.com','4377662708','2024-08-27'
	)
INSERT INTO Students  
VALUES 
	(
		'981-911-148','Meshwa','Shah','Meshwa@gmail.com','4377662709','2024-09-28'
	)
INSERT INTO Students 
VALUES 
	(
		'981-911-149','Rahil','Shah','Rahil@gmail.com','4377662710','2024-10-29'
	)
