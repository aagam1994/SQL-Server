--SELECT * FROM Students

EXEC dbo.StudentsPro '981-911-130','Rajendra','Shah','Rajendra@gmail.com','4377662691','2024-01-17'
EXEC dbo.StudentsPro '981-911-131','Bhanuben','Shah','Bhanuben@gmail.com','4377662692','2024-01-18'
EXEC dbo.StudentsPro '981-911-132','Ushaben','Shah','Ushaben@gmail.com','4377662693','2024-01-19'
EXEC dbo.StudentsPro '981-911-133','Gunvantlal','Shah','Gunvantlal@gmail.com','4377662694','2024-01-17'
EXEC dbo.StudentsPro '981-911-134','Keval','Shah','Keval@gmail.com','4377662695','2024-01-18'
EXEC dbo.StudentsPro '981-911-135','Parth','Shah','Parth@gmail.com','4377662696','2024-01-19'
EXEC dbo.StudentsPro '981-911-136','Rushabh','Shah','Rushabh@gmail.com','4377662697','2024-01-17'
EXEC dbo.StudentsPro '981-911-137','Dhara','Shah','Dhara@gmail.com','4377662698','2024-01-18'
EXEC dbo.StudentsPro '981-911-138','Vidit','Shah','Vidit@gmail.com','4377662699','2024-01-19'
EXEC dbo.StudentsPro '981-911-139','Hetvi','Shah','Hetvi@gmail.com','4377662700','2024-01-17'


